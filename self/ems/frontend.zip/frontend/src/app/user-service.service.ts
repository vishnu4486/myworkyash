import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from  '@angular/common/http';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  httpOptions: { headers: HttpHeaders; };
  baseUrl: string = 'http://localhost:5000';
  userData: Object;
 

  constructor(private http: HttpClient) {
    this. httpOptions = {
      headers: new HttpHeaders({ 
          'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin':this.baseUrl
      })
    };

  }


  getUserList(){
    return this.http.get<User[]>(this.baseUrl+"/users/get",this.httpOptions);
  }

  login(data){
    this.http.post(this.baseUrl +"/users/login", data, this.httpOptions).subscribe(result=>this.userData=result);
    console.log(this.userData);
    if ( this.userData ) {
      return this.userData;
  }else{
    return 0;
  }
}


}