import { Component, OnInit,Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  @Input()
  all:number=0;

  @Input()
  male:number=0;

  @Input()
  female:number=0;
  selectedRadioButtonValue: string="All";

  @Output()
  countRadio: EventEmitter<string>=new EventEmitter<string>();

  onchaneRadio(){

    this.countRadio.emit(this.selectedRadioButtonValue);
  }

  constructor() { }

  ngOnInit() {
    this.countRadio.emit(this.selectedRadioButtonValue);
  }

}
