import { Users } from './../../../../my-dream-app/src/app/users';
// import { EmpdataService } from './../../../../my-dream-app/src/app/empdata.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl,Validators } from '@angular/forms';
import { UserService } from '../user-service.service';
import { Routes, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private empdata: UserService,private routercust: Router) {

   }
   showFlag:boolean=false;
   msg:string;
formdata;
  ngOnInit() {
    this.formdata=new FormGroup({
      userName: new FormControl("",Validators.compose([
     Validators.required,
     Validators.minLength(6)
   ])),
password:new FormControl("",this.passwordvalidation)

    });
  }

  passwordvalidation(formcontrol){
    if(formcontrol.value.length <5 ){
      return {
        "password": true
      };
    }
  }

  onClickSubmit(data){
    this.showFlag=true;
    if(this.empdata.login(data)){
      this.routercust.navigate(['/users']);
    this.msg="login is successful";
    }else{
      this.msg="please check your username and password";
        }
    setTimeout(() => {
      this.showFlag=false;
    }, 3000);
  }
}
