export interface User {
    userId:string,
    userFullName: string,
    userName: string,
    userPassword: string,
    userEmail: string,
    userPhone: string,
    userRole: string,
    userAdress:string,
    created_At: string,
    updated_At:string
}

