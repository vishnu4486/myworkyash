import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  allCount:number=0;
  maleCount:number=0;
  femaleCount:number=0;
  showdata:string;

  emp =[
    {"empid": "1","empName":"vishnu  ","gender":"Male","phone":8421976605},
    {"empid": "2","empName":"pratic","gender":"Male","phone":8421976605},
    {"empid": "3","empName":"ameya ","gender":"Male","phone":8421976605},
    {"empid": "4","empName":"Ram","gender":"Male","phone":8421976605},
    {"empid": "5","empName":"Jasss","gender":"Female","phone":8421976605},
    {"empid": "6","empName":"swati","gender":"Female","phone":8421976605},
    {"empid": "7","empName":"ashu","gender":"Female","phone":8421976605},
    {"empid": "8","empName":"sneha","gender":"Female","phone":8421976605}
  ]
   getAllCount(){
this.allCount=this.emp.length;
this.emp.map(e=>{
 if(e.gender=="Male")
 {
   this.maleCount++;
 }else{
   this.femaleCount++;
 }
})
  }

  childer(data){
    this.showdata=data;
  }
refresh(){
  this.showdata="All"
}
  constructor() { }

  ngOnInit() {
    this.getAllCount();
  }

}
