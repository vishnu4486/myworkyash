import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../category.service';
import { Category } from '../category';
import { Expense } from '../expense';
import { ExpenseService } from '../expense.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(private categoryService:CategoryService,private expenseService:ExpenseService) { }
  data;
  catId;
  categoryList:Category[];
  ngOnInit() {
    this.getAllCategories();
  }

  getAllCategories(){
    this.categoryService.getAllCategories().subscribe(data=>this.categoryList=data);
  }

  temp: Expense = {
    _id:"",
    categoryId:0,
    expenseId:"",
    expenseName:"",
    amount:0
  };

  addExpense(){
    console.log(this.temp);
   
     this.expenseService.addExpense(this.temp);
     
    //  this.temp = {
    //     _id:"",
    //     categoryId:0,
    //     expenseId:"",
    //     expenseName:"",
    //     amount:0
    //   };
  
  }
}
