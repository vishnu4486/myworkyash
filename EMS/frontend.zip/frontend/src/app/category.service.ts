import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Category } from './category';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  constructor(private http: HttpClient) { }

  baseUrl: string = 'http://localhost:3000/routes';

  getAllCategories():Observable<Category[]>{
    const httpOptions = {
      headers: new HttpHeaders({ 
          'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin':this.baseUrl
      })
    };
     return this.http.get<Category[]>(this.baseUrl+"/categories",httpOptions);
  }
}
