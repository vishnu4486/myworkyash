export interface Expense {
    _id:string,
    categoryId:number,
    expenseId:string,
    expenseName:string,
    amount:number
}
