import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from  '@angular/common/http';
import { Expense } from './expense';
import {Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ExpenseService {

  constructor(private http: HttpClient) { }

  baseUrl: string = 'http://localhost:3000/routes';

  getExpenseList():Observable<Expense[]>{
    const httpOptions = {
      headers: new HttpHeaders({ 
          'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin':this.baseUrl
      })
    };
     return this.http.get<Expense[]>(this.baseUrl+"/expenses",httpOptions);
  }

  deleteExpense(expenseId:number){
    return this.http.delete<Expense[]>(this.baseUrl +"/expense/"+ expenseId);
  }

  updateExpense(expense:Expense,expenseId:string){
    const httpOptions = {
      headers: new HttpHeaders({ 
          'Content-Type': 'application/json', 
        'Access-Control-Allow-Origin':this.baseUrl
      })
    };
    return this.http.put(this.baseUrl + '/expense/' + expenseId,httpOptions);
  }

  addExpense(expense:Expense){
    const httpOptions = {
        headers: new HttpHeaders({ 
            'Content-Type': 'application/json', 
          'Access-Control-Allow-Origin': this.baseUrl
        })
      };
    return this.http.post(this.baseUrl+"/expense",  httpOptions);
}

  // getExpensesByCategory(categoryId:number){
  //   const httpOptions = {
  //     headers: new HttpHeaders({ 
  //         'Content-Type': 'application/json', 
  //       'Access-Control-Allow-Origin':this.baseUrl
  //     })
  //   };
  //    return this.http.get<Expense[]>(this.baseUrl+"/expenses/"+categoryId,httpOptions);
  // }
}
