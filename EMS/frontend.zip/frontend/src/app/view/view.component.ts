import { Component, OnInit } from '@angular/core';
import { Expense } from '../expense';
import { ExpenseService } from '../expense.service';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  expenseList: Expense[];
  data: any;

  constructor(private expenseService: ExpenseService) {
  }

  ngOnInit() {
    this.getExpenseList();
  }

  getExpenseList() {
     this.expenseService.getExpenseList().subscribe(data=>this.expenseList=data);
  }

  deleteExpense(id:number){
     this.expenseService.deleteExpense(id).subscribe(data=>this.expenseService.getExpenseList().subscribe(data=>{this.expenseList=data}));
 }

 editRowId:"";

 editExpense(id){
   this.editRowId=id;
 }

 updateExpense(expense:Expense){
   this.editRowId="";
   this.expenseService.updateExpense(expense,expense._id).subscribe(data=>this.expenseService.getExpenseList().subscribe(data=>{this.expenseList=data}));
 }
}
